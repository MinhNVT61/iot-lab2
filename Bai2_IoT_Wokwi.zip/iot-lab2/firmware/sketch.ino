#include <WiFi.h>
#include <PubSubClient.h>
#include <DHTesp.h>
#include <time.h>
#include <sys/time.h>
#include "secrets.h"
WiFiClient net;
PubSubClient mqtt(net);
DHTesp dht;
const int DHT_PIN=15, TRIG_PIN=5, ECHO_PIN=18, LED_PIN=2;
unsigned long lastSend=0, sequenceNo=0, lastRetry=0;
char bootId[24];
float readDistanceCm() {
  digitalWrite(TRIG_PIN,LOW); delayMicroseconds(2);
  digitalWrite(TRIG_PIN,HIGH); delayMicroseconds(10); digitalWrite(TRIG_PIN,LOW);
  unsigned long duration=pulseIn(ECHO_PIN,HIGH,30000);
  return duration ? duration*0.0343f/2.0f : NAN;
}
void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN,OUTPUT); pinMode(ECHO_PIN,INPUT); pinMode(LED_PIN,OUTPUT);
  dht.setup(DHT_PIN,DHTesp::DHT22);
  snprintf(bootId,sizeof(bootId),"%08lx%08lx",(unsigned long)esp_random(),(unsigned long)esp_random());
  WiFi.begin("Wokwi-GUEST","",6);
  configTime(0,0,"pool.ntp.org","time.google.com");
  mqtt.setServer(MQTT_HOST,MQTT_PORT); mqtt.setBufferSize(768);
}
void loop() {
  unsigned long now=millis();
  if (WiFi.status()!=WL_CONNECTED) {
    if(now-lastRetry>=5000){lastRetry=now; WiFi.reconnect();}
    delay(10); return;
  }
  if (!mqtt.connected()) {
    if(now-lastRetry>=3000){
      lastRetry=now;
      String id=String("lab2-")+bootId;
      bool ok=MQTT_USER[0] ? mqtt.connect(id.c_str(),MQTT_USER,MQTT_PASSWORD) : mqtt.connect(id.c_str());
      Serial.printf("MQTT %s rc=%d\n",ok?"connected":"failed",mqtt.state());
    }
    return;
  }
  mqtt.loop();
  if(now-lastSend<5000) return;
  lastSend=now;
  struct timeval tv; gettimeofday(&tv,NULL);
  if(tv.tv_sec<1700000000){Serial.println("Waiting NTP");return;}
  TempAndHumidity values=dht.getTempAndHumidity(); float distance=readDistanceCm();
  if(!isfinite(values.temperature)||!isfinite(values.humidity)||!isfinite(distance)){
    Serial.println("Invalid sensor; skipped");return;
  }
  gettimeofday(&tv,NULL);
  struct tm utc; gmtime_r(&tv.tv_sec,&utc);
  char date[32], timestamp[40]; strftime(date,sizeof(date),"%Y-%m-%dT%H:%M:%S",&utc);
  snprintf(timestamp,sizeof(timestamp),"%s.%03ldZ",date,(long)(tv.tv_usec/1000));
  sequenceNo++;
  char payload[600];
  int n=snprintf(payload,sizeof(payload),
    "{\"device_id\":\"esp32-01\",\"boot_id\":\"%s\",\"sequence\":%lu,\"timestamp\":\"%s\",\"temperature\":%.2f,\"humidity\":%.2f,\"distance_cm\":%.2f,\"rssi\":%d,\"uptime_s\":%lu}",
    bootId,sequenceNo,timestamp,values.temperature,values.humidity,distance,WiFi.RSSI(),millis()/1000);
  bool ok=n>0 && n<(int)sizeof(payload) && mqtt.publish(MQTT_TOPIC,payload);
  Serial.printf("%s | publish=%s\n",payload,ok?"OK":"FAILED");
  if(ok){digitalWrite(LED_PIN,HIGH);delay(80);digitalWrite(LED_PIN,LOW);}
}
