#pragma once
// Copy to secrets.h in Wokwi; never publish real credentials.
#define MQTT_HOST "YOUR_BROKER_HOST"
#define MQTT_PORT 1883
#define MQTT_USER ""
#define MQTT_PASSWORD ""
#define MQTT_TOPIC "iot/bai2/esp32-01/telemetry"
